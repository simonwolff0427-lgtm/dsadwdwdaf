package com.example.opbroadcast;

import de.maxhenkel.voicechat.api.VoicechatApi;
import de.maxhenkel.voicechat.api.VoicechatConnection;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.VoicechatServerApi;
import de.maxhenkel.voicechat.api.audiochannel.StaticAudioChannel;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.events.MicrophonePacketEvent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Registers with Simple Voice Chat's plugin API. While a player is in
 * "broadcasting" mode (toggled via /vbroadcast on), any audio their mic sends
 * gets copied out to every other connected Voice Chat player directly, instead
 * of only the players within normal proximity range — so it's heard server-wide
 * by anyone who has the mod installed. Players without the mod simply can't
 * receive this at all; there's no protocol-level way around that, which is why
 * /broadcast (plain text) exists as the everyone-hears-it fallback.
 */
public class VoiceBroadcastHandler implements VoicechatPlugin {

    private final OpBroadcastPlugin plugin;
    private final Set<UUID> broadcasting = ConcurrentHashMap.newKeySet();
    private VoicechatServerApi api;

    // One outgoing static channel per currently-broadcasting sender, reused
    // across packets rather than recreated every time.
    private final Map<UUID, StaticAudioChannel> channels = new ConcurrentHashMap<>();
    // Which listener UUIDs have already been added as a target on that sender's channel.
    private final Map<UUID, Set<UUID>> channelTargets = new ConcurrentHashMap<>();

    public VoiceBroadcastHandler(OpBroadcastPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getPluginId() {
        return "opbroadcast";
    }

    @Override
    public void initialize(VoicechatApi api) {
        if (api instanceof VoicechatServerApi serverApi) {
            this.api = serverApi;
        }
    }

    @Override
    public void registerEvents(EventRegistration registration) {
        registration.registerEvent(MicrophonePacketEvent.class, this::onMicrophonePacket);
    }

    public void setBroadcasting(UUID playerId, boolean on) {
        if (on) {
            broadcasting.add(playerId);
        } else {
            broadcasting.remove(playerId);
            channels.remove(playerId);
            channelTargets.remove(playerId);
        }
    }

    private void onMicrophonePacket(MicrophonePacketEvent event) {
        if (api == null) return;

        VoicechatConnection sender = event.getSenderConnection();
        if (sender == null) return;

        UUID senderId = sender.getPlayer().getUuid();
        if (!broadcasting.contains(senderId)) return;

        byte[] opusData = event.getPacket().getOpusEncodedData();
        if (opusData == null) return;

        StaticAudioChannel channel = channels.computeIfAbsent(senderId,
                id -> api.createStaticAudioChannel(UUID.randomUUID()));
        if (channel == null) return;

        Set<UUID> targets = channelTargets.computeIfAbsent(senderId, id -> ConcurrentHashMap.newKeySet());

        // Make sure every currently online player (except the sender, who hears
        // their own mic locally already) is a target of this channel. New joiners
        // get picked up automatically since this runs on every packet.
        for (Player online : Bukkit.getOnlinePlayers()) {
            UUID listenerId = online.getUniqueId();
            if (listenerId.equals(senderId)) continue;
            if (targets.contains(listenerId)) continue;

            VoicechatConnection connection = api.getConnectionOf(listenerId);
            if (connection != null) {
                channel.addTarget(connection);
                targets.add(listenerId);
            }
            // If connection is null, they don't have Voice Chat connected —
            // we'll just check again on the next packet.
        }

        channel.send(opusData);
    }
}
